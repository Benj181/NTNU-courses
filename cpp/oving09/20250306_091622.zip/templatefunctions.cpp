#include "templatefunctions.h"

void testTemplateFunctions(){
    // Her kan du teste templatefunksjonene dine
}

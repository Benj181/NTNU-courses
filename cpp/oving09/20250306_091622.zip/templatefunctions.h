#pragma once
#include <random>
#include <iostream>
#include <string>
#include <vector>

// BEGIN 4a

// END 4a

// BEGIN 4b

// END 4b

void testTemplateFunctions();
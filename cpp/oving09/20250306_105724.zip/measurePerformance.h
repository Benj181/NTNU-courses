#pragma once

double measurePerformanceUnique();
double measurePerformanceShared();

double measurePerformanceStack();
double measurePerformanceHeap();

#include "MyArray.h"

// BEGIN 5d
void testMyArray(){
    
}
// END 5d
#include "mastermind.h"

// BEGIN: 4
//Oppgave 4a til 4j løses her forutenom 4e og 4f
//playMastermind(){}
// END: 4

// BEGIN: 4e
///*returverdi*/ checkCharactersAndPosition(/*param 1: code, param 2: guess*/) {}
// END: 4e

// BEGIN: 4f
///*returverdi*/ checkCharacters(/*param 1: code, param 2: guess*/) {}
// END: 4f

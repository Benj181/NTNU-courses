#pragma once
#include "utilities.h"
#include "std_lib_facilities.h"

void testCallByValue();
void testCallByReference();
void testSwapNumbers();
void testPrintStudent();
void testIsInProgram();
void testreadInputToString();
void testString();
#pragma once
#include "std_lib_facilities.h"
#include "utilities.h"

// BEGIN: 4
//deklarer playMastermind her
// END: 4

// BEGIN: 4e
//deklarer checkCharactersAndPosition her
// END: 4e

// BEGIN: 4f
//deklarer checkCharacters her
// END: 4f
